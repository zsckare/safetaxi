<div id="acerca" class="card mostrar">
	<div class="padding-largo">
		<div class="row"></div>
		<div class="row">
			<div class="col s4 m3 l3 offset-s2 offset-m2"><img src="/assets/img/logo.png" alt="" class="responsive-img"></div>
			<div class="col s4 m3 l3 offset-m2"><img src="/assets/img/logo-alianza.png" alt="" class="responsive-img"></div>
		</div>
		<div class="row padding-largo">
			<div class="row">
				<p class="center-align dos">Taxi Seguro Alianza APP</p>
				<p class="center-align" style="font-size:1.5em;" >Es un Servicio del Sindicato Alianza Durango</p>
			</div>
			
			<div class="row">
				<p class="center-align">Desarrollado por:</p>
				<p class="center-align">Antonio Alvarez Guevara | Pedro Castro Quintanila </p>
				<p class="center-align"> Carlos Gerardo Villa Avila</p>
			</div>
		</div>
	</div>
</div>